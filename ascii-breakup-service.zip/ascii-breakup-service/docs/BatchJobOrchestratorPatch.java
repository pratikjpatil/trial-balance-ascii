package com.tcs.fincore.ReportBuilder.batch.orchestrator;

/**
 * ╔══════════════════════════════════════════════════════════════════════════════╗
 * ║  INTEGRATION PATCH – BatchJobOrchestrator.java                              ║
 * ║  ASCII Breakup Service Integration                                           ║
 * ╠══════════════════════════════════════════════════════════════════════════════╣
 * ║  This file is NOT meant to be compiled as-is.                               ║
 * ║  It documents the EXACT DIFFS to apply to BatchJobOrchestrator.java.        ║
 * ╚══════════════════════════════════════════════════════════════════════════════╝
 *
 * ── STEP 1 ── Add import ───────────────────────────────────────────────────────
 *
 * import com.tcs.fincore.ReportBuilder.service.ascii.orchestrator.AsciiBreakupOrchestrator;
 *
 * ── STEP 2 ── Inject the new service (add to existing @RequiredArgsConstructor / constructor) ──
 *
 * private final AsciiBreakupOrchestrator asciiBreakupOrchestrator;
 *
 * ── STEP 3 ── Modify materializeData() to return batchResults ─────────────────
 *
 * Change:
 *     private void materializeData(AnalysisResult analysis) {
 *
 * To:
 *     private Map<String, Map<String, Map<String, Object>>> materializeData(AnalysisResult analysis) {
 *
 * Change the method body's last line from:
 *     log.info("Phase 2 complete in {}ms: {} patterns materialized", elapsed, batchResults.size());
 *
 * To:
 *     log.info("Phase 2 complete in {}ms: {} patterns materialized", elapsed, batchResults.size());
 *     return batchResults;
 *     }
 *
 * ── STEP 4 ── Update processJobAsync() to capture batchResults and trigger ASCII ─
 *
 * In processJobAsync(), change:
 *
 *   // BEFORE:
 *   if (analysis.useBatchMode) {
 *       updatePhase(status, BatchJobStatus.JobPhase.MATERIALIZING_DATA);
 *       materializeData(analysis);
 *   } else {
 *       log.info("Batch mode not beneficial, using sequential processing");
 *   }
 *   // PHASE 3: Generate Reports
 *   updatePhase(status, BatchJobStatus.JobPhase.GENERATING_REPORTS);
 *   generateReportsInBatches(request, analysis, status);
 *
 *   // AFTER:
 *   Map<String, Map<String, Map<String, Object>>> batchResults = null;
 *   if (analysis.useBatchMode) {
 *       updatePhase(status, BatchJobStatus.JobPhase.MATERIALIZING_DATA);
 *       batchResults = materializeData(analysis);
 *
 *       // ── ASCII STORE HOOK ──────────────────────────────────────────────────
 *       // Push CGL data into Redis for async ASCII file generation.
 *       // Must happen before generateReportsInBatches so data is ready.
 *       String reportId = analysis.template.getReportMeta().getReportId();
 *       if (asciiBreakupOrchestrator.isAsciiEnabled(reportId) && batchResults != null) {
 *           asciiBreakupOrchestrator.storeCglDataFromBatchResults(
 *               request.getJobId(),
 *               request.getTemplateId(),
 *               reportId,
 *               batchResults,
 *               request.getVaryingDimension().getValues()
 *           );
 *       }
 *       // ─────────────────────────────────────────────────────────────────────
 *   } else {
 *       log.info("Batch mode not beneficial, using sequential processing");
 *   }
 *
 *   // PHASE 3: Generate Reports
 *   updatePhase(status, BatchJobStatus.JobPhase.GENERATING_REPORTS);
 *   generateReportsInBatches(request, analysis, status);
 *
 *   // ── ASCII GENERATE HOOK ──────────────────────────────────────────────────
 *   // Trigger async ASCII generation AFTER all reports are done.
 *   // This does NOT block the batch job completion.
 *   String reportIdForAscii = analysis.template.getReportMeta().getReportId();
 *   if (asciiBreakupOrchestrator.isAsciiEnabled(reportIdForAscii)) {
 *       String balanceDate = resolveBalanceDateString(request);
 *       asciiBreakupOrchestrator.generateAsciiFilesAsync(
 *           request.getJobId(),
 *           request.getTemplateId(),
 *           reportIdForAscii,
 *           analysis.template,
 *           request.getVaryingDimension().getValues(),
 *           balanceDate
 *       );
 *   }
 *   // ─────────────────────────────────────────────────────────────────────────
 *
 * ── STEP 5 ── Add helper method resolveBalanceDateString() ────────────────────
 *
 * Add this private method to BatchJobOrchestrator:
 */

// ─── Example helper method to add to BatchJobOrchestrator ─────────────────────

// private String resolveBalanceDateString(BatchJobRequest request) {
//     if (request.getCommonParams() == null) return LocalDate.now().toString();
//     // Try common param names used for balance date
//     for (String key : List.of("balanceDate", "BALANCE_DATE", "reportDate", "date")) {
//         Object val = request.getCommonParams().get(key);
//         if (val != null) {
//             String s = String.valueOf(val).trim();
//             if (!s.isBlank()) return s;
//         }
//     }
//     return LocalDate.now().toString();
// }

/**
 * ── STEP 6 ── Add application.properties entries ─────────────────────────────
 *
 * # ========================================
 * # ASCII Breakup Service Configuration
 * # ========================================
 * report.ascii.enabled-reports=NWSA,YSA,PNL
 * report.ascii.redis.ttl-hours=2
 * report.ascii.output-path=/reports/ascii/
 *
 * ── STEP 7 ── Ensure @EnableAsync + "reportExecutor" bean exist ───────────────
 * The @Async("reportExecutor") in AsciiBreakupOrchestrator requires an executor
 * named "reportExecutor". If this bean doesn't already exist, add:
 *
 * @Bean("reportExecutor")
 * public Executor reportExecutor() {
 *     ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
 *     executor.setCorePoolSize(4);
 *     executor.setMaxPoolSize(10);
 *     executor.setQueueCapacity(200);
 *     executor.setThreadNamePrefix("ascii-async-");
 *     executor.initialize();
 *     return executor;
 * }
 *
 * ── NOTES ─────────────────────────────────────────────────────────────────────
 * • The batch job COMPLETES normally before ASCII files are generated.
 *   ASCII generation is fully async and does not affect batch job status.
 * • If ASCII generation fails for a branch, it is logged as an error but
 *   does NOT fail the batch job.
 * • Redis TTL is 2 hours by default – ensure ASCII generation finishes within
 *   this window for large branch counts. Increase if needed.
 * • The 'reportExecutor' pool should have enough threads to handle concurrent
 *   ASCII jobs if multiple batch jobs run simultaneously.
 */
public class BatchJobOrchestratorPatch {
    // Documentation-only class. Do not instantiate.
    private BatchJobOrchestratorPatch() {}
}
