package com.tcs.fincore.ReportBuilder.service.ascii.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Represents the balance of a single CGL (General Ledger) code for a given branch.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CglBalance {
    private String cglCode;
    private double balance;
}
