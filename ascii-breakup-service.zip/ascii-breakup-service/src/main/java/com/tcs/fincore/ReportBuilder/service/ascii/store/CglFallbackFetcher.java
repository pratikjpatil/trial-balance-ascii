package com.tcs.fincore.ReportBuilder.service.ascii.store;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * Fallback mechanism when CGL data is not available in Redis.
 *
 * <p>Fetches individual CGL balances directly from {@code GL_BALANCE}
 * for a given branch + balance-date + set of CGL codes.
 *
 * <p>This is used by {@code AsciiBreakupOrchestrator} when Redis misses.
 * It batches the CGL IN-clause into chunks of {@value #CHUNK_SIZE} to
 * avoid Oracle limits on IN-list sizes.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class CglFallbackFetcher {

    /** Max CGLs per IN-clause (Oracle supports up to 1000). */
    private static final int CHUNK_SIZE = 500;

    private final NamedParameterJdbcTemplate jdbc;

    /**
     * Fetch per-CGL aggregated balances from the database.
     *
     * @param branchCode  Branch code filter
     * @param balanceDate Balance date (as string, e.g. "2025-12-31")
     * @param cglCodes    Set of CGL codes to fetch
     * @return Map of cglCode → sum(BALANCE)
     */
    public Map<String, Double> fetchCglBalances(String branchCode,
                                                 String balanceDate,
                                                 Set<String> cglCodes) {
        if (cglCodes == null || cglCodes.isEmpty()) return Collections.emptyMap();

        log.info("DB fallback fetch: branch={}, date={}, cgls={}", branchCode, balanceDate, cglCodes.size());

        Map<String, Double> result = new HashMap<>(cglCodes.size());
        List<String> cglList = new ArrayList<>(cglCodes);

        // Chunk the CGL list to stay within Oracle IN-clause limits
        for (int i = 0; i < cglList.size(); i += CHUNK_SIZE) {
            List<String> chunk = cglList.subList(i, Math.min(i + CHUNK_SIZE, cglList.size()));
            Map<String, Double> chunkResult = fetchChunk(branchCode, balanceDate, chunk);
            result.putAll(chunkResult);
        }

        log.info("DB fallback: fetched {} CGL balances for branch {}", result.size(), branchCode);
        return result;
    }

    private Map<String, Double> fetchChunk(String branchCode,
                                            String balanceDate,
                                            List<String> cglChunk) {
        String sql = """
                SELECT CGL, SUM(BALANCE) AS AGG_BALANCE
                FROM GL_BALANCE
                WHERE BRANCH_CODE = :branchCode
                  AND BALANCE_DATE = TO_DATE(:balanceDate, 'YYYY-MM-DD')
                  AND CGL IN (:cgls)
                GROUP BY CGL
                """;

        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("branchCode", branchCode)
                .addValue("balanceDate", balanceDate)
                .addValue("cgls", cglChunk);

        try {
            Map<String, Double> chunkResult = new HashMap<>();
            jdbc.query(sql, params, rs -> {
                String cgl = rs.getString("CGL");
                double bal = rs.getDouble("AGG_BALANCE");
                chunkResult.put(cgl, bal);
            });
            return chunkResult;
        } catch (Exception e) {
            log.error("DB fallback chunk query failed for branch {}: {}", branchCode, e.getMessage(), e);
            return Collections.emptyMap();
        }
    }
}
