package com.tcs.fincore.ReportBuilder.service.ascii.store;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * Redis-backed store for CGL balance data used by the ASCII breakup service.
 *
 * <p>Key format:
 * <pre>rb:breakup:{jobId}:{templateId}:{branchCode}</pre>
 * Value: JSON-serialised {@code Map<String, Double>} (cglCode → balance).
 *
 * <p>TTL is configurable via {@code report.ascii.redis.ttl-hours} (default 2 h).
 * If Redis data is absent the caller is expected to use the DB fallback.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class RedisBreakupStore {

    private static final String KEY_PREFIX = "rb:breakup:";
    private static final TypeReference<Map<String, Double>> MAP_TYPE = new TypeReference<>() {};

    private final StringRedisTemplate redisTemplate;
    private final ObjectMapper objectMapper;

    @Value("${report.ascii.redis.ttl-hours:2}")
    private int ttlHours;

    // ─── Write ─────────────────────────────────────────────────────────────────

    /**
     * Store CGL balance map for a specific branch under this job/template.
     *
     * @param jobId      Batch job identifier
     * @param templateId Report template identifier
     * @param branchCode Branch code (the varying dimension value)
     * @param cglData    Map of cglCode → aggregated balance
     */
    public void storeCglData(String jobId,
                              String templateId,
                              String branchCode,
                              Map<String, Double> cglData) {
        if (cglData == null || cglData.isEmpty()) {
            log.debug("No CGL data to store for branch {}", branchCode);
            return;
        }

        String key = buildKey(jobId, templateId, branchCode);
        try {
            String json = objectMapper.writeValueAsString(cglData);
            redisTemplate.opsForValue().set(key, json, ttlHours, TimeUnit.HOURS);
            log.debug("Stored {} CGL entries for branch {} (key={})", cglData.size(), branchCode, key);
        } catch (Exception e) {
            log.error("Failed to store CGL data in Redis for branch {}: {}", branchCode, e.getMessage());
        }
    }

    /**
     * Bulk-store CGL data for multiple branches in one pass.
     * Uses pipelining to minimise round-trips.
     *
     * @param jobId             Batch job identifier
     * @param templateId        Report template identifier
     * @param branchCglDataMap  Map of branchCode → (cglCode → balance)
     */
    public void storeCglDataBulk(String jobId,
                                   String templateId,
                                   Map<String, Map<String, Double>> branchCglDataMap) {
        if (branchCglDataMap == null || branchCglDataMap.isEmpty()) return;

        redisTemplate.executePipelined((connection) -> {
            branchCglDataMap.forEach((branchCode, cglData) -> {
                if (cglData == null || cglData.isEmpty()) return;
                String key = buildKey(jobId, templateId, branchCode);
                try {
                    String json = objectMapper.writeValueAsString(cglData);
                    byte[] keyBytes  = key.getBytes();
                    byte[] valueBytes = json.getBytes();
                    long ttlSeconds  = TimeUnit.HOURS.toSeconds(ttlHours);
                    connection.stringCommands().setEx(keyBytes, ttlSeconds, valueBytes);
                } catch (Exception e) {
                    log.error("Pipeline store failed for branch {}: {}", branchCode, e.getMessage());
                }
            });
            return null;
        });

        log.info("Bulk-stored CGL data for {} branches (job={}, template={})",
                branchCglDataMap.size(), jobId, templateId);
    }

    // ─── Read ──────────────────────────────────────────────────────────────────

    /**
     * Retrieve the CGL balance map for a branch.
     *
     * @return populated map, or empty map if not found / expired
     */
    public Map<String, Double> getCglData(String jobId,
                                           String templateId,
                                           String branchCode) {
        String key = buildKey(jobId, templateId, branchCode);
        try {
            String json = redisTemplate.opsForValue().get(key);
            if (json == null || json.isBlank()) {
                log.debug("Cache MISS for branch {} (key={})", branchCode, key);
                return Collections.emptyMap();
            }
            Map<String, Double> data = objectMapper.readValue(json, MAP_TYPE);
            log.debug("Cache HIT for branch {} – {} CGLs", branchCode, data.size());
            return data;
        } catch (Exception e) {
            log.error("Failed to read CGL data from Redis for branch {}: {}", branchCode, e.getMessage());
            return Collections.emptyMap();
        }
    }

    /**
     * Check whether CGL data is cached for this branch.
     */
    public boolean hasCglData(String jobId, String templateId, String branchCode) {
        return Boolean.TRUE.equals(redisTemplate.hasKey(buildKey(jobId, templateId, branchCode)));
    }

    /**
     * Delete CGL data for a branch (e.g. after successful ASCII generation to free memory).
     */
    public void deleteCglData(String jobId, String templateId, String branchCode) {
        redisTemplate.delete(buildKey(jobId, templateId, branchCode));
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    private String buildKey(String jobId, String templateId, String branchCode) {
        return KEY_PREFIX + jobId + ":" + templateId + ":" + branchCode;
    }
}
