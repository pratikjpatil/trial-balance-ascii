package com.tcs.fincore.ReportBuilder.service.ascii.parser;

import com.tcs.fincore.ReportBuilder.model.ReportTemplate;
import com.tcs.fincore.ReportBuilder.service.ascii.model.RowBreakupInfo;
import com.tcs.fincore.ReportBuilder.service.ascii.model.VariableGroup;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * Parses the report template to extract breakup-relevant metadata.
 *
 * <p>It walks all FORMULA cells whose inner variables are DB_SUM queries on GL_BALANCE
 * and extracts CGL codes grouped by their logic type (N, DP, CN, R, SP, SN).
 *
 * <p>This parsing result is used by:
 * <ul>
 *   <li>{@code AsciiBreakupGenerator} – to lay out the breakup ASCII file</li>
 *   <li>{@code AsciiBreakupGenerator} – to produce the trial balance ASCII file</li>
 *   <li>{@code RedisBreakupStore} (fallback) – to know which CGLs to fetch from DB</li>
 * </ul>
 */
@Slf4j
@Component
public class TemplateBreakupParser {

    /**
     * Parse the template and return ordered breakup rows.
     * Only FORMULA cells with at least one DB_SUM variable are included.
     *
     * @param template the fully expanded, ID-assigned template
     * @return ordered list of {@link RowBreakupInfo} (one per qualifying FORMULA cell)
     */
    @SuppressWarnings("unchecked")
    public List<RowBreakupInfo> parse(ReportTemplate template) {
        List<RowBreakupInfo> result = new ArrayList<>();

        if (template.getReportData() == null || template.getReportData().getRows() == null) {
            return result;
        }

        List<ReportTemplate.ColumnDefinition> cols = template.getReportData().getColumns();

        for (ReportTemplate.Row row : template.getReportData().getRows()) {
            if (row.getCells() == null) continue;

            for (int cellIdx = 0; cellIdx < row.getCells().size(); cellIdx++) {
                ReportTemplate.Cell cell = row.getCells().get(cellIdx);
                if (cell == null) continue;
                if (!"FORMULA".equalsIgnoreCase(cell.getType())) continue;
                if (cell.getVariables() == null || cell.getVariables().isEmpty()) continue;

                List<VariableGroup> groups = extractVariableGroups(cell.getVariables());
                if (groups.isEmpty()) continue;

                // Derive a label – try to find a TEXT cell on the same row that has text
                String label = deriveLabel(row);
                // Also try to find comp code from TEXT cells
                String compCode = deriveCompCode(row);

                RowBreakupInfo info = RowBreakupInfo.builder()
                        .cellId(cell.getId())
                        .rowId(row.getId())
                        .label(label)
                        .compCode(compCode)
                        .expression(cell.getExpression())
                        .variableGroups(groups)
                        .build();

                result.add(info);
            }
        }

        log.info("TemplateBreakupParser: extracted {} formula rows with CGL groups", result.size());
        return result;
    }

    /**
     * Collect all unique CGL codes referenced across the entire template (used for DB fallback).
     */
    @SuppressWarnings("unchecked")
    public Set<String> collectAllCglCodes(ReportTemplate template) {
        Set<String> allCgls = new LinkedHashSet<>();
        if (template.getReportData() == null || template.getReportData().getRows() == null) return allCgls;

        for (ReportTemplate.Row row : template.getReportData().getRows()) {
            if (row.getCells() == null) continue;
            for (ReportTemplate.Cell cell : row.getCells()) {
                if (!"FORMULA".equalsIgnoreCase(cell.getType())) continue;
                if (cell.getVariables() == null) continue;
                for (Map.Entry<String, Object> varEntry : cell.getVariables().entrySet()) {
                    if (!(varEntry.getValue() instanceof Map)) continue;
                    Map<String, Object> varMap = (Map<String, Object>) varEntry.getValue();
                    List<String> cgls = extractCglList(varMap);
                    allCgls.addAll(cgls);
                }
            }
        }
        return allCgls;
    }

    // ─── Private Helpers ─────────────────────────────────────────────────────

    @SuppressWarnings("unchecked")
    private List<VariableGroup> extractVariableGroups(Map<String, Object> variables) {
        List<VariableGroup> groups = new ArrayList<>();

        // Process in a defined order matching typical JEXL expression order
        for (Map.Entry<String, Object> varEntry : variables.entrySet()) {
            String varName = varEntry.getKey();
            Object varVal  = varEntry.getValue();
            if (!(varVal instanceof Map)) continue;

            Map<String, Object> varMap = (Map<String, Object>) varVal;
            String typeStr = String.valueOf(varMap.getOrDefault("type", "")).toUpperCase();
            if (!typeStr.startsWith("DB_")) continue;

            List<String> cgls = extractCglList(varMap);
            if (cgls.isEmpty()) continue;

            VariableGroup.LogicType logicType = detectLogicType(varName, varMap);

            groups.add(VariableGroup.builder()
                    .varName(varName)
                    .logicType(logicType)
                    .cglCodes(cgls)
                    .build());
        }
        return groups;
    }

    /**
     * Detect the logic type from the variable name and its BALANCE filter (if any).
     *
     * Convention used in templates:
     *   N  – no BALANCE filter, varName = "N"
     *   DP – BALANCE > 0 filter present, varName = "DP"
     *   CN – BALANCE < 0 filter present, varName = "CN"
     *   R  – varName = "R"
     *   SP – varName = "SP"
     *   SN – varName = "SN"
     *
     * Fall back to checking variable name if filter is ambiguous.
     */
    @SuppressWarnings("unchecked")
    private VariableGroup.LogicType detectLogicType(String varName, Map<String, Object> varMap) {
        // Primary: check by variable name (fast path)
        switch (varName.toUpperCase()) {
            case "N":  return VariableGroup.LogicType.N;
            case "DP": return VariableGroup.LogicType.DP;
            case "CN": return VariableGroup.LogicType.CN;
            case "R":  return VariableGroup.LogicType.R;
            case "SP": return VariableGroup.LogicType.SP;
            case "SN": return VariableGroup.LogicType.SN;
        }

        // Secondary: inspect BALANCE filter
        Object filtersObj = varMap.get("filters");
        if (filtersObj instanceof Map) {
            Map<String, Object> filters = (Map<String, Object>) filtersObj;
            Object balanceFilter = filters.get("BALANCE");
            if (balanceFilter != null) {
                String filterStr = balanceFilter.toString();
                if (filterStr.contains(">")) return VariableGroup.LogicType.DP;
                if (filterStr.contains("<")) return VariableGroup.LogicType.CN;
            }
        }

        return VariableGroup.LogicType.UNKNOWN;
    }

    /**
     * Extract CGL codes from a variable's filter definition.
     * Handles:
     *   - CGL: [{op:"IN", value:[...]}]
     *   - CGL: {op:"=", value:"123"}
     *   - CGL: {op:"LIKE", value:"7%"}  (prefix wildcards – expand if needed, else skip)
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    private List<String> extractCglList(Map<String, Object> varMap) {
        List<String> result = new ArrayList<>();
        Object filtersObj = varMap.get("filters");
        if (!(filtersObj instanceof Map)) return result;

        Map<String, Object> filters = (Map<String, Object>) filtersObj;
        Object cglFilter = filters.get("CGL");
        if (cglFilter == null) return result;

        // Normalise to list of condition maps
        List<Map<String, Object>> conditions = new ArrayList<>();
        if (cglFilter instanceof List) {
            for (Object item : (List) cglFilter) {
                if (item instanceof Map) conditions.add((Map<String, Object>) item);
            }
        } else if (cglFilter instanceof Map) {
            conditions.add((Map<String, Object>) cglFilter);
        }

        for (Map<String, Object> cond : conditions) {
            String op = String.valueOf(cond.getOrDefault("op", "=")).toUpperCase();
            Object val = cond.get("value");

            if ("IN".equals(op) && val instanceof Collection) {
                for (Object v : (Collection<?>) val) {
                    if (v != null && !String.valueOf(v).isBlank()) {
                        result.add(String.valueOf(v).trim());
                    }
                }
            } else if ("=".equals(op) && val != null) {
                result.add(String.valueOf(val).trim());
            }
            // LIKE patterns (e.g. "7%") are intentionally skipped from CGL lists
            // because they cannot be pre-enumerated. The trial balance will note this.
        }
        return result;
    }

    /** Try to pull a meaningful label from TEXT cells on the same row. */
    private String deriveLabel(ReportTemplate.Row row) {
        if (row.getCells() == null) return row.getId();
        for (ReportTemplate.Cell cell : row.getCells()) {
            if ("TEXT".equalsIgnoreCase(cell.getType()) && cell.getValue() != null) {
                String v = String.valueOf(cell.getValue()).trim();
                if (!v.isBlank() && v.length() > 3) return v; // prefer longer text cells
            }
        }
        return row.getId();
    }

    /** Try to extract a comp-code value from TEXT cells (typically a short numeric code). */
    private String deriveCompCode(ReportTemplate.Row row) {
        if (row.getCells() == null) return "";
        for (ReportTemplate.Cell cell : row.getCells()) {
            if ("TEXT".equalsIgnoreCase(cell.getType()) && cell.getValue() != null) {
                String v = String.valueOf(cell.getValue()).trim();
                // Comp codes are typically 5-digit zero-padded strings
                if (v.matches("\\d{4,6}")) return v;
            }
        }
        return "";
    }
}
