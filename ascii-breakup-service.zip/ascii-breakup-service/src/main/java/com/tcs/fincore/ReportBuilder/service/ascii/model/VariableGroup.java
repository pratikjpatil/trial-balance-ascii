package com.tcs.fincore.ReportBuilder.service.ascii.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Represents a named variable group within a formula cell (e.g. N, DP, CN, R, SP, SN).
 * Each variable group maps to a set of CGL codes and an associated logic type.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VariableGroup {

    /**
     * Variable name as used in the JEXL expression (e.g. "N", "DP", "CN", "R", "SP", "SN")
     */
    private String varName;

    /**
     * Logic type derived from template variable structure:
     * N  = NORMAL_BALANCE           – include balance as-is
     * DP = DEBIT_POSITIVE           – include only if balance > 0
     * CN = CREDIT_NEGATIVE          – include only if balance < 0
     * R  = REVERSE                  – negate the balance
     * SP = SWING_POSITIVE           – include sum only if total sum > 0
     * SN = SWING_NEGATIVE           – include sum only if total sum < 0
     */
    public enum LogicType { N, DP, CN, R, SP, SN, UNKNOWN }

    private LogicType logicType;

    /**
     * The list of CGL codes belonging to this group.
     */
    private List<String> cglCodes;

    /**
     * The computed sum of balances for this group (after applying conditional logic).
     */
    private double computedSum;

    /**
     * Whether this group's value is "active" (condition met) for print in the ASCII output.
     * For N / DP / CN / R: always printed per CGL (filtered).
     * For SP / SN: the whole group is printed only if the sum meets the swing condition.
     */
    private boolean active;

    /**
     * Human-readable description of the logic for the trial balance file.
     */
    public String logicDescription() {
        return switch (logicType) {
            case N  -> "Normal Balance";
            case DP -> "Debit Positive (balance > 0 only)";
            case CN -> "Credit Negative (balance < 0 only)";
            case R  -> "Reverse (negated)";
            case SP -> "Swing Positive (show sum only if total > 0)";
            case SN -> "Swing Negative (show sum only if total < 0)";
            default -> "Unknown";
        };
    }
}
