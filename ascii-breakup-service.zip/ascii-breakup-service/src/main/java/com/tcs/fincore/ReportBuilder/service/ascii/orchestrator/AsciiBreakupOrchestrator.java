package com.tcs.fincore.ReportBuilder.service.ascii.orchestrator;

import com.tcs.fincore.ReportBuilder.model.ReportTemplate;
import com.tcs.fincore.ReportBuilder.service.ascii.generator.AsciiBreakupGenerator;
import com.tcs.fincore.ReportBuilder.service.ascii.model.RowBreakupInfo;
import com.tcs.fincore.ReportBuilder.service.ascii.model.VariableGroup;
import com.tcs.fincore.ReportBuilder.service.ascii.parser.TemplateBreakupParser;
import com.tcs.fincore.ReportBuilder.service.ascii.store.CglFallbackFetcher;
import com.tcs.fincore.ReportBuilder.service.ascii.store.RedisBreakupStore;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * Top-level orchestrator for ASCII breakup and trial balance file generation.
 *
 * <h3>Invocation points</h3>
 * <ol>
 *   <li>{@link #storeCglDataFromBatchResults} – called by {@code BatchJobOrchestrator}
 *       immediately after {@code dataMaterializer.materializeAll()} to push CGL data
 *       into Redis for later async consumption.</li>
 *   <li>{@link #generateAsciiFilesAsync} – called after all reports are generated;
 *       picks up data from Redis (with DB fallback) and produces the two ASCII files
 *       per branch.</li>
 * </ol>
 *
 * <h3>Fallback strategy</h3>
 * If Redis data is absent for a branch (TTL expired, Redis unavailable, etc.),
 * the orchestrator parses the template to collect all CGL codes and fetches
 * balances directly from {@code GL_BALANCE}.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AsciiBreakupOrchestrator {

    private final TemplateBreakupParser templateBreakupParser;
    private final RedisBreakupStore     redisBreakupStore;
    private final CglFallbackFetcher    cglFallbackFetcher;
    private final AsciiBreakupGenerator asciiBreakupGenerator;

    /** Report IDs eligible for ASCII generation (comma-separated). */
    @Value("${report.ascii.enabled-reports:NWSA,YSA,PNL}")
    private Set<String> asciiEnabledReports;

    // ─── Phase A: Store CGL data from batchResults into Redis ─────────────────

    /**
     * Extract CGL balances from the materializer's batch results and store them
     * in Redis keyed by branch code.
     *
     * <p>Call this <em>immediately after</em> {@code dataMaterializer.materializeAll()}
     * returns, <em>before</em> {@code resultDistributor.initialize()}.
     *
     * @param jobId        Batch job ID
     * @param templateId   Template ID (e.g. "1075")
     * @param reportId     Logical report name (e.g. "YSA")
     * @param batchResults The full materializer result:
     *                     {@code Map<patternId, Map<branchCode, Map<cglCode, balance>>>}
     * @param branchCodes  Ordered list of all branch codes in the batch
     */
    public void storeCglDataFromBatchResults(
            String jobId,
            String templateId,
            String reportId,
            Map<String, Map<String, Map<String, Object>>> batchResults,
            List<String> branchCodes) {

        if (!isAsciiEnabled(reportId)) {
            log.debug("ASCII generation disabled for report {}", reportId);
            return;
        }
        if (batchResults == null || batchResults.isEmpty()) {
            log.warn("batchResults is empty – nothing to store for ASCII (job={})", jobId);
            return;
        }

        log.info("Extracting CGL data for ASCII – job={}, report={}, branches={}",
                jobId, reportId, branchCodes.size());

        // Build per-branch CGL map: branchCode → { cglCode → balance }
        Map<String, Map<String, Double>> branchCglData = new HashMap<>();

        for (String branchCode : branchCodes) {
            Map<String, Double> cglBalances = new HashMap<>();

            for (Map.Entry<String, Map<String, Map<String, Object>>> patternEntry : batchResults.entrySet()) {
                Map<String, Map<String, Object>> patternByBranch = patternEntry.getValue();
                if (patternByBranch == null) continue;

                Map<String, Object> branchData = patternByBranch.get(branchCode);
                if (branchData == null) continue;

                // bulkKey = CGL code when CGL is the bulk dimension
                branchData.forEach((bulkKey, aggValue) -> {
                    if (bulkKey == null || "DEFAULT".equals(bulkKey)) return;
                    if (aggValue == null) return;

                    double balance = 0.0;
                    if (aggValue instanceof Number) {
                        balance = ((Number) aggValue).doubleValue();
                    } else {
                        try {
                            balance = Double.parseDouble(aggValue.toString());
                        } catch (NumberFormatException ignored) {
                            return;
                        }
                    }

                    // Merge: same CGL may appear in multiple patterns (e.g. different date slices)
                    cglBalances.merge(bulkKey, balance, Double::sum);
                });
            }

            if (!cglBalances.isEmpty()) {
                branchCglData.put(branchCode, cglBalances);
            }
        }

        // Bulk-push to Redis
        redisBreakupStore.storeCglDataBulk(jobId, templateId, branchCglData);
        log.info("CGL data stored in Redis for {} branches", branchCglData.size());
    }

    // ─── Phase B: Generate ASCII files async ──────────────────────────────────

    /**
     * Generate ASCII breakup and trial balance files for all branches in this job.
     *
     * <p>Runs asynchronously so it does not block batch job completion.
     * Each branch is processed sequentially within the async invocation to control
     * memory usage; increase pool size in config if parallelism is needed.
     *
     * @param jobId       Batch job ID
     * @param templateId  Template ID
     * @param reportId    Logical report name (e.g. "YSA")
     * @param template    The fully expanded report template (for parser and fallback)
     * @param branchCodes All branch codes to generate files for
     * @param balanceDate Balance date as string (YYYY-MM-DD)
     */
    @Async("reportExecutor")
    public void generateAsciiFilesAsync(String jobId,
                                         String templateId,
                                         String reportId,
                                         ReportTemplate template,
                                         List<String> branchCodes,
                                         String balanceDate) {

        if (!isAsciiEnabled(reportId)) return;

        log.info("=== ASCII GENERATION STARTED: job={}, report={}, branches={} ===",
                jobId, reportId, branchCodes.size());
        long start = System.currentTimeMillis();

        // Parse template once – reused for all branches
        List<RowBreakupInfo> parsedRows = templateBreakupParser.parse(template);
        if (parsedRows.isEmpty()) {
            log.warn("No breakup rows found in template {} – skipping ASCII generation", templateId);
            return;
        }

        // Collect all CGLs referenced in template (for fallback queries)
        Set<String> allTemplateCgls = parsedRows.stream()
                .flatMap(r -> r.getVariableGroups().stream())
                .flatMap(g -> g.getCglCodes() != null ? g.getCglCodes().stream() : java.util.stream.Stream.empty())
                .collect(Collectors.toSet());

        LocalDate reportDate = parseDate(balanceDate);

        AtomicInteger success = new AtomicInteger(0);
        AtomicInteger failure = new AtomicInteger(0);

        for (String branchCode : branchCodes) {
            try {
                // 1. Retrieve CGL data from Redis
                Map<String, Double> cglData = redisBreakupStore.getCglData(jobId, templateId, branchCode);

                // 2. DB fallback if Redis missed
                if (cglData.isEmpty()) {
                    log.debug("Redis miss for branch {} – using DB fallback", branchCode);
                    cglData = cglFallbackFetcher.fetchCglBalances(branchCode, balanceDate, allTemplateCgls);
                }

                if (cglData.isEmpty()) {
                    log.warn("No CGL data available for branch {} – skipping ASCII generation", branchCode);
                    failure.incrementAndGet();
                    continue;
                }

                // 3. Deep-copy parsed rows to prevent state pollution between branches
                List<RowBreakupInfo> branchRows = deepCopyRows(parsedRows);

                // 4. Generate files
                asciiBreakupGenerator.generate(reportId, templateId, branchCode, reportDate, branchRows, cglData);

                // 5. Optionally delete Redis key to free memory (comment out if retry needed)
                redisBreakupStore.deleteCglData(jobId, templateId, branchCode);

                success.incrementAndGet();

            } catch (Exception e) {
                log.error("ASCII generation failed for branch {}: {}", branchCode, e.getMessage(), e);
                failure.incrementAndGet();
            }
        }

        long elapsed = System.currentTimeMillis() - start;
        log.info("=== ASCII GENERATION COMPLETE: job={}, success={}, failure={}, time={}ms ===",
                jobId, success.get(), failure.get(), elapsed);
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    public boolean isAsciiEnabled(String reportId) {
        if (reportId == null) return false;
        return asciiEnabledReports.contains(reportId.toUpperCase());
    }

    private LocalDate parseDate(String dateStr) {
        try {
            return LocalDate.parse(dateStr);
        } catch (DateTimeParseException e) {
            log.warn("Could not parse balance date '{}', using today", dateStr);
            return LocalDate.now();
        }
    }

    /**
     * Deep-copy parsed rows so that each branch gets fresh, mutable VariableGroup objects.
     * (AsciiBreakupGenerator mutates computedSum / active on the groups.)
     */
    private List<RowBreakupInfo> deepCopyRows(List<RowBreakupInfo> rows) {
        List<RowBreakupInfo> copy = new ArrayList<>(rows.size());
        for (RowBreakupInfo row : rows) {
            List<VariableGroup> grpCopy = new ArrayList<>();
            for (VariableGroup g : row.getVariableGroups()) {
                grpCopy.add(VariableGroup.builder()
                        .varName(g.getVarName())
                        .logicType(g.getLogicType())
                        .cglCodes(g.getCglCodes() != null ? new ArrayList<>(g.getCglCodes()) : Collections.emptyList())
                        .computedSum(0.0)
                        .active(false)
                        .build());
            }
            copy.add(RowBreakupInfo.builder()
                    .cellId(row.getCellId())
                    .rowId(row.getRowId())
                    .label(row.getLabel())
                    .compCode(row.getCompCode())
                    .expression(row.getExpression())
                    .variableGroups(grpCopy)
                    .finalAmount(0.0)
                    .build());
        }
        return copy;
    }
}
