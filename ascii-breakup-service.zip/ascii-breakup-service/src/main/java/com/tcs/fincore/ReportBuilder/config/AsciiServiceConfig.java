package com.tcs.fincore.ReportBuilder.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.StringRedisTemplate;

/**
 * Spring configuration for the ASCII Breakup Service.
 *
 * <p>Registers a dedicated {@link StringRedisTemplate} bean for the ASCII service
 * to keep its Redis operations isolated from the main cache.
 *
 * <p>Properties consumed (see {@code application.properties}):
 * <pre>
 * report.ascii.redis.ttl-hours=2
 * report.ascii.enabled-reports=NWSA,YSA,PNL
 * report.ascii.output-path=/reports/ascii/
 * </pre>
 */
@Configuration
public class AsciiServiceConfig {

    /**
     * StringRedisTemplate for the ASCII service.
     * Uses the same Redis connection factory as the main application
     * (configured via {@code spring.data.redis.*} in application.properties).
     */
    @Bean("asciiRedisTemplate")
    public StringRedisTemplate asciiRedisTemplate(RedisConnectionFactory connectionFactory) {
        return new StringRedisTemplate(connectionFactory);
    }
}
