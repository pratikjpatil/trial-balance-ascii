package com.tcs.fincore.ReportBuilder.service.ascii.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Breakup information for a single template row (corresponding to one head / comp-code).
 * This is the unit of work for both the breakup file and the trial balance file.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RowBreakupInfo {

    /** Cell ID (e.g. cell_R__1_C__5) – the inner amount formula cell */
    private String cellId;

    /** Row ID from the template */
    private String rowId;

    /** Human-readable label for this row / head (e.g. comp code or nomenclature) */
    private String label;

    /** Comp code (head code) this row represents */
    private String compCode;

    /** Ordered list of variable groups in this row's formula */
    private List<VariableGroup> variableGroups;

    /** The JEXL expression for this row's inner cell (for display in trial balance) */
    private String expression;

    /**
     * The final computed inner amount (after all group logic applied).
     * This should match what the report itself shows.
     */
    private double finalAmount;
}
