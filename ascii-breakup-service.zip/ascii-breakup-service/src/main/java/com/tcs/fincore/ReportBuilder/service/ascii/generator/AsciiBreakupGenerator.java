package com.tcs.fincore.ReportBuilder.service.ascii.generator;

import com.tcs.fincore.ReportBuilder.service.ascii.model.CglBalance;
import com.tcs.fincore.ReportBuilder.service.ascii.model.RowBreakupInfo;
import com.tcs.fincore.ReportBuilder.service.ascii.model.VariableGroup;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Generates two ASCII files per branch per report:
 *
 * <ol>
 *   <li><b>Breakup file</b> – head-wise, variable-wise CGL detail showing
 *       each CGL code and its balance, with variable totals and head totals.</li>
 *   <li><b>Trial Balance file</b> – explains how each head's inner amount was
 *       derived, including the formula expression and per-variable contribution.</li>
 * </ol>
 *
 * <h3>Logic types</h3>
 * <ul>
 *   <li>N  – Normal Balance:    each CGL balance used as-is</li>
 *   <li>R  – Reverse:           each CGL balance negated</li>
 *   <li>DP – Debit Positive:    include CGL only if balance {@literal >} 0</li>
 *   <li>CN – Credit Negative:   include CGL only if balance {@literal <} 0</li>
 *   <li>SP – Swing Positive:    sum all CGLs; print group only if sum {@literal >} 0</li>
 *   <li>SN – Swing Negative:    sum all CGLs; print group only if sum {@literal <} 0</li>
 * </ul>
 */
@Slf4j
@Component
public class AsciiBreakupGenerator {

    private static final int LINE_WIDTH = 100;
    private static final String SEPARATOR   = "=".repeat(LINE_WIDTH);
    private static final String THIN_SEP    = "─".repeat(LINE_WIDTH);
    private static final String COL_PIPE    = " | ";

    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("dd-MMM-yyyy");

    @Value("${report.ascii.output-path:/reports/ascii/}")
    private String outputBasePath;

    // ─── Public API ────────────────────────────────────────────────────────────

    /**
     * Generate BOTH the breakup file and the trial balance file for a single branch.
     *
     * @param reportId    Logical report identifier (e.g. "YSA")
     * @param templateId  Template identifier
     * @param branchCode  Branch code for which files are generated
     * @param reportDate  Balance date used in header
     * @param rows        Parsed row breakup info (from {@code TemplateBreakupParser})
     * @param cglData     Map of cglCode → balance (from Redis or DB fallback)
     * @return            Pair of (breakupFilePath, trialBalanceFilePath)
     */
    public GeneratedFilePair generate(String reportId,
                                      String templateId,
                                      String branchCode,
                                      LocalDate reportDate,
                                      List<RowBreakupInfo> rows,
                                      Map<String, Double> cglData) {

        // Enrich rows with computed balances (mutates the group.computedSum / group.active fields)
        List<RowBreakupInfo> enrichedRows = enrichRows(rows, cglData);

        String dateStr   = reportDate.format(DATE_FMT).toUpperCase();
        String dirPath   = buildDirPath(reportId, branchCode, dateStr);
        ensureDir(dirPath);

        String breakupPath = dirPath + reportId + "_" + branchCode + "_" + reportDate + "_BREAKUP.txt";
        String trialPath   = dirPath + reportId + "_" + branchCode + "_" + reportDate + "_TRIAL.txt";

        writeBreakupFile(breakupPath, reportId, branchCode, dateStr, enrichedRows, cglData);
        writeTrialBalanceFile(trialPath, reportId, branchCode, dateStr, enrichedRows);

        log.info("Generated ASCII files for branch {} – breakup: {}, trial: {}", branchCode, breakupPath, trialPath);
        return new GeneratedFilePair(breakupPath, trialPath);
    }

    // ─── Enrichment ────────────────────────────────────────────────────────────

    /**
     * Walk each row's variable groups and compute per-group sums + active flags
     * based on the logic type, then set the row's final amount.
     */
    private List<RowBreakupInfo> enrichRows(List<RowBreakupInfo> rows, Map<String, Double> cglData) {
        for (RowBreakupInfo row : rows) {
            double rowTotal = 0.0;
            for (VariableGroup grp : row.getVariableGroups()) {
                double groupContribution = computeGroupContribution(grp, cglData);
                grp.setComputedSum(groupContribution);
                rowTotal += groupContribution;
            }
            row.setFinalAmount(rowTotal);
        }
        return rows;
    }

    /**
     * Apply the group's logic type and return the net contribution to the row total.
     * Also sets {@link VariableGroup#isActive()} for use in the breakup print loop.
     */
    private double computeGroupContribution(VariableGroup grp, Map<String, Double> cglData) {
        List<String> cgls = grp.getCglCodes();
        if (cgls == null || cgls.isEmpty()) {
            grp.setActive(false);
            return 0.0;
        }

        switch (grp.getLogicType()) {

            case N: {
                double sum = sumCgls(cgls, cglData, false);
                grp.setActive(true);
                grp.setComputedSum(sum);
                return sum;
            }

            case R: {
                double sum = -1.0 * sumCgls(cgls, cglData, false);
                grp.setActive(true);
                grp.setComputedSum(sum);
                return sum;
            }

            case DP: {
                // DB already filtered BALANCE > 0; here we still guard defensively
                double sum = cgls.stream()
                        .mapToDouble(c -> {
                            double b = cglData.getOrDefault(c, 0.0);
                            return b > 0 ? b : 0.0;
                        })
                        .sum();
                grp.setActive(true);
                grp.setComputedSum(sum);
                return sum;
            }

            case CN: {
                // DB already filtered BALANCE < 0; negate for display
                double sum = cgls.stream()
                        .mapToDouble(c -> {
                            double b = cglData.getOrDefault(c, 0.0);
                            return b < 0 ? (-1.0 * b) : 0.0;
                        })
                        .sum();
                grp.setActive(true);
                grp.setComputedSum(sum);
                return sum;
            }

            case SP: {
                double rawSum = sumCgls(cgls, cglData, false);
                boolean active = rawSum > 0;
                grp.setActive(active);
                grp.setComputedSum(active ? rawSum : 0.0);
                return grp.getComputedSum();
            }

            case SN: {
                double rawSum = sumCgls(cgls, cglData, false);
                boolean active = rawSum < 0;
                grp.setActive(active);
                // SN contributes its absolute value when active
                grp.setComputedSum(active ? rawSum : 0.0);
                return grp.getComputedSum();
            }

            default: {
                grp.setActive(false);
                grp.setComputedSum(0.0);
                return 0.0;
            }
        }
    }

    private double sumCgls(List<String> cgls, Map<String, Double> cglData, boolean negated) {
        double sum = cgls.stream().mapToDouble(c -> cglData.getOrDefault(c, 0.0)).sum();
        return negated ? -sum : sum;
    }

    // ─── Breakup File ──────────────────────────────────────────────────────────

    private void writeBreakupFile(String filePath,
                                   String reportId,
                                   String branchCode,
                                   String dateStr,
                                   List<RowBreakupInfo> rows,
                                   Map<String, Double> cglData) {
        try (PrintWriter w = openWriter(filePath)) {
            printBreakupHeader(w, reportId, branchCode, dateStr);

            for (RowBreakupInfo row : rows) {
                printHeadBreakup(w, row, cglData);
            }

            printFooter(w, "END OF BREAKUP REPORT");
        } catch (IOException e) {
            log.error("Failed to write breakup file {}: {}", filePath, e.getMessage(), e);
        }
    }

    private void printBreakupHeader(PrintWriter w, String reportId, String branchCode, String dateStr) {
        w.println(SEPARATOR);
        printCentered(w, "BREAKUP REPORT : " + reportId);
        printCentered(w, "BRANCH CODE    : " + branchCode);
        printCentered(w, "BALANCE DATE   : " + dateStr);
        w.println(SEPARATOR);
        w.println();
    }

    private void printHeadBreakup(PrintWriter w, RowBreakupInfo row, Map<String, Double> cglData) {
        // HEAD header
        w.println(THIN_SEP);
        w.printf("HEAD : %-10s  %s%n", row.getCompCode(), row.getLabel());
        w.println(THIN_SEP);

        for (VariableGroup grp : row.getVariableGroups()) {
            printVariableGroup(w, grp, cglData);
        }

        // Head total
        w.println();
        w.printf("  %-70s %s%n", "HEAD INNER TOTAL:", formatAmount(row.getFinalAmount()));
        w.println();
    }

    private void printVariableGroup(PrintWriter w, VariableGroup grp, Map<String, Double> cglData) {
        w.printf("  ┌── VARIABLE: %-4s  [%s]%n", grp.getVarName(), grp.logicDescription());

        // Swing types: only print CGLs if the swing condition is met
        boolean swingInactive = (grp.getLogicType() == VariableGroup.LogicType.SP
                || grp.getLogicType() == VariableGroup.LogicType.SN)
                && !grp.isActive();

        if (swingInactive) {
            w.printf("  │   [CONDITION NOT MET – swing sum = %s, group suppressed]%n",
                    formatAmount(sumCgls(grp.getCglCodes(), cglData, false)));
        } else {
            w.printf("  │   %-20s %-16s%n", "CGL CODE", "BALANCE");
            w.printf("  │   %-20s %-16s%n", "────────────────────", "────────────────");

            double variableTotal = 0.0;
            for (String cglCode : grp.getCglCodes()) {
                double rawBalance = cglData.getOrDefault(cglCode, 0.0);
                double printBalance = applyLogicForDisplay(grp.getLogicType(), rawBalance);

                // DP: skip zero-balance CGLs (those that didn't meet balance > 0)
                if (grp.getLogicType() == VariableGroup.LogicType.DP && rawBalance <= 0) continue;
                // CN: skip zero-balance CGLs
                if (grp.getLogicType() == VariableGroup.LogicType.CN && rawBalance >= 0) continue;

                w.printf("  │   %-20s %16s%n", cglCode, formatAmount(printBalance));
                variableTotal += printBalance;
            }

            w.printf("  │   %-20s %16s%n", "────────────────────", "────────────────");
            w.printf("  └── VARIABLE TOTAL        %16s%n", formatAmount(variableTotal));
        }
        w.println();
    }

    /**
     * Convert raw balance to the display value based on logic type.
     */
    private double applyLogicForDisplay(VariableGroup.LogicType logicType, double rawBalance) {
        return switch (logicType) {
            case R  -> -1.0 * rawBalance;
            case CN -> -1.0 * rawBalance;   // CN stores negatives; show as positive outflow
            default -> rawBalance;
        };
    }

    // ─── Trial Balance File ────────────────────────────────────────────────────

    private void writeTrialBalanceFile(String filePath,
                                        String reportId,
                                        String branchCode,
                                        String dateStr,
                                        List<RowBreakupInfo> rows) {
        try (PrintWriter w = openWriter(filePath)) {
            printTrialHeader(w, reportId, branchCode, dateStr);

            for (RowBreakupInfo row : rows) {
                printTrialRow(w, row);
            }

            printFooter(w, "END OF TRIAL BALANCE REPORT");
        } catch (IOException e) {
            log.error("Failed to write trial balance file {}: {}", filePath, e.getMessage(), e);
        }
    }

    private void printTrialHeader(PrintWriter w, String reportId, String branchCode, String dateStr) {
        w.println(SEPARATOR);
        printCentered(w, "TRIAL BALANCE REPORT : " + reportId);
        printCentered(w, "BRANCH CODE          : " + branchCode);
        printCentered(w, "BALANCE DATE         : " + dateStr);
        w.println(SEPARATOR);
        w.println();
    }

    private void printTrialRow(PrintWriter w, RowBreakupInfo row) {
        w.println(THIN_SEP);
        w.printf("HEAD      : %-10s  %s%n", row.getCompCode(), row.getLabel());
        w.printf("CELL ID   : %s%n", row.getCellId());
        w.printf("EXPRESSION: %s%n", Objects.toString(row.getExpression(), "N/A"));
        w.println();

        w.printf("  %-6s  %-40s  %20s  %s%n",
                "VAR", "LOGIC", "CONTRIBUTION", "CGL COUNT");
        w.printf("  %-6s  %-40s  %20s  %s%n",
                "──────", "────────────────────────────────────────",
                "────────────────────", "─────────");

        for (VariableGroup grp : row.getVariableGroups()) {
            String swingNote = "";
            if ((grp.getLogicType() == VariableGroup.LogicType.SP
                    || grp.getLogicType() == VariableGroup.LogicType.SN)
                    && !grp.isActive()) {
                swingNote = " [SUPPRESSED]";
            }

            w.printf("  %-6s  %-40s  %20s  %d%s%n",
                    grp.getVarName(),
                    grp.logicDescription(),
                    formatAmount(grp.getComputedSum()),
                    grp.getCglCodes() != null ? grp.getCglCodes().size() : 0,
                    swingNote);
        }

        w.println();
        w.printf("  %-47s  %20s%n", "NET INNER AMOUNT (sum of active variables):",
                formatAmount(row.getFinalAmount()));
        w.println();
    }

    // ─── Shared Utilities ──────────────────────────────────────────────────────

    private void printFooter(PrintWriter w, String message) {
        w.println(SEPARATOR);
        printCentered(w, message);
        w.println(SEPARATOR);
    }

    private void printCentered(PrintWriter w, String text) {
        int padding = Math.max(0, (LINE_WIDTH - text.length()) / 2);
        w.println(" ".repeat(padding) + text);
    }

    private PrintWriter openWriter(String path) throws IOException {
        return new PrintWriter(new BufferedWriter(
                new OutputStreamWriter(new FileOutputStream(path), StandardCharsets.UTF_8)));
    }

    private String buildDirPath(String reportId, String branchCode, String dateStr) {
        // e.g. /reports/ascii/YSA/001234/31-DEC-2025/
        return outputBasePath
                + reportId + File.separator
                + branchCode + File.separator
                + dateStr + File.separator;
    }

    private void ensureDir(String dirPath) {
        File dir = new File(dirPath);
        if (!dir.exists() && !dir.mkdirs()) {
            log.warn("Could not create directory: {}", dirPath);
        }
    }

    /**
     * Format amount in Indian numbering style: 12,34,56,789.00
     * Negative amounts are shown with a leading '-'.
     */
    private String formatAmount(double amount) {
        boolean negative = amount < 0;
        double abs = Math.abs(amount);

        // Integer part + decimal
        long intPart  = (long) abs;
        long decPart  = Math.round((abs - intPart) * 100);

        String intStr = formatIndian(intPart);
        String result = intStr + "." + String.format("%02d", decPart);
        return negative ? "-" + result : result;
    }

    private String formatIndian(long n) {
        if (n == 0) return "0";
        String s = Long.toString(n);
        if (s.length() <= 3) return s;

        // Last 3 digits, then groups of 2
        StringBuilder sb = new StringBuilder();
        sb.insert(0, s.substring(s.length() - 3));
        s = s.substring(0, s.length() - 3);

        while (!s.isEmpty()) {
            int take = Math.min(2, s.length());
            sb.insert(0, ",");
            sb.insert(0, s.substring(s.length() - take));
            s = s.substring(0, s.length() - take);
        }
        return sb.toString();
    }

    // ─── Result Type ──────────────────────────────────────────────────────────

    public record GeneratedFilePair(String breakupFilePath, String trialFilePath) {}
}
